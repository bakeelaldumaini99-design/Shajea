const students = [
"سحر الصايدي","علياء عباس السوسوة","هويدا عبدالسلام الجعفري","هاجر محمد قائد الجماعي","يونس الشهاري","عبدالرحمن النظاري","أديب العزي الجرافي","رشيد السيري","عباس العشاري","عمار حيدرة","عمرو مصطفى الحريمي","مجيب نجيب العواضي","صهيب العامري","شهاب حيدرة","إياد عبدالله حمزة","ريان عبدالحكيم عشة","بكيل شاجع الدميني","عرفات مصطفى الحريمي","عبدالواسع الحميدي","نواف حسن المليكي","مأمون حمود البريهي","مصعب محمد جرعم","إبراهيم أحمد الزمر","البخاري مأمون الغيثي","رشاد حميد الصلاحي","عبدالله أبو راس","رضوان العواضي","عبدالرزاق البجلي","عبدالله حاتم الدعيس","حسين الحوت","علي أبو حليقة","محمد رضوان","معتز السماوي","رأفت الضراسي","عصام عبده عبدالله","إبراهيم البعداني","إبراهيم حمود نعمان البريهي","علي العواضي","أحمد الجعيدي","حسام الحميدي","مصعب منصور العواضي","بشير أحمد سعيد","زكرياء اليفرسي","ثرياء علي درهم الحسيني"
];

const scholars = [
"مصعب منصور العواضي","زكرياء اليفرسي","هويدا الجعفري","ريم عسقين","أديب الجرافي","سليم الحميدي","ماجد الإدريسي","يونس الشهاري","عبدالله عمر","باهر الرشيدي","علي الحبيشي","مراد غابشة","عبدالواسع الحميدي","إياد حمزة","أحمد القحيف","نواف المليكي","مصعب جرعم","بكيل شاجع الدميني","البخاري الغيثي","عباس العشاري","عمر عبدالعزيز","بشار الحاج","رمزي الكامل","جمال جميل المليكي","صخر الكامل","جهاد سلام","عبدالرحمن اليفرسي","زيدان الصوفي","محمد سلمان","أحمد المليكي","أحمد حمود غالب","سياف اللهبي","محمد عبدالعالم محرم","عبدالله ابو راس","رشاد الصلاحي","عبدالرزاق البجلي","غيث الصانع"
];

const namesEl = document.getElementById("names");
const emptyEl = document.getElementById("empty");
const search = document.getElementById("studentSearch");

function renderStudents(filter=""){
  const q = filter.trim().toLowerCase();
  const list = students.filter(n => n.toLowerCase().includes(q));
  namesEl.innerHTML = list.map(n => `<span class="name-pill">${n}</span>`).join("");
  emptyEl.style.display = list.length ? "none" : "block";
}
renderStudents();
search.addEventListener("input", e => renderStudents(e.target.value));

document.getElementById("scholarList").innerHTML =
  scholars.map(n => `<span>${n}</span>`).join("");

document.getElementById("year").textContent = new Date().getFullYear();

const menu = document.getElementById("menu");
const nav = document.getElementById("nav");
menu.addEventListener("click", ()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", ()=>nav.classList.remove("open")));

const progress = document.getElementById("progress");
const toTop = document.getElementById("toTop");
window.addEventListener("scroll", ()=>{
  const max = document.documentElement.scrollHeight - innerHeight;
  progress.style.width = `${Math.min(100, scrollY/max*100)}%`;
  toTop.style.display = scrollY > 600 ? "grid" : "none";
});
toTop.addEventListener("click", ()=>scrollTo({top:0,behavior:"smooth"}));

const observer = new IntersectionObserver(entries=>{
  entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add("reveal"); });
},{threshold:.08});
document.querySelectorAll(".section,.timeline-item,.book,.country,.digital-card,.quote-section").forEach(el=>observer.observe(el));
